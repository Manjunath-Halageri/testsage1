import { ObjectLengthPipe } from './object-length.pipe';

describe('ObjectLengthPipe', () => {
  it('create an instance', () => {
    const pipe = new ObjectLengthPipe();
    expect(pipe).toBeTruthy();
  });
});
