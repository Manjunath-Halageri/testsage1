import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defect-module-level',
  templateUrl: './defect-module-level.component.html',
  styleUrls: ['./defect-module-level.component.css']
})
export class DefectModuleLevelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
