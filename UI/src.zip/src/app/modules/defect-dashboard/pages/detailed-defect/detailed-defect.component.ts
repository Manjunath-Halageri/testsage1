import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailed-defect',
  templateUrl: './detailed-defect.component.html',
  styleUrls: ['./detailed-defect.component.css']
})
export class DetailedDefectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
