import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defect-feature-level',
  templateUrl: './defect-feature-level.component.html',
  styleUrls: ['./defect-feature-level.component.css']
})
export class DefectFeatureLevelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
