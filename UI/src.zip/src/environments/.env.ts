export default {
    'npm_package_version': '1.0.0'
};
  